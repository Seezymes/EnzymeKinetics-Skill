@echo off
REM GitHub 代码上传脚本
REM 用途：将 EnzymeKinetics-Skill 代码上传到 GitHub

echo ========================================
echo EnzymeKinetics-Skill 代码上传工具
echo ========================================
echo.

REM 切换到项目目录
cd /d "%~dp0"

echo [1/6] 检查 Git 安装...
git --version
if errorlevel 1 (
    echo 错误：未检测到 Git！请先安装 Git。
    echo 访问：https://git-scm.com/download/win
    pause
    exit /b 1
)
echo Git 已安装
echo.

echo [2/6] 配置 Git 用户信息...
git config user.name "Qi Gao"
git config user.email "joan.gao@seezymes.com"
echo 用户信息已配置
echo.

echo [3/6] 初始化 Git 仓库...
git init
echo 仓库已初始化
echo.

echo [4/6] 添加所有文件...
git add .
echo 文件已添加到暂存区
echo.

echo [5/6] 创建初始提交...
git commit -m "Initial commit: EnzymeKinetics-Skill v2.0.0

Features:
- Weighted nonlinear regression
- Bootstrap confidence intervals with BCa correction
- Outlier detection (residuals, Cook's distance, robust Z-score)
- Multiple linear transformation methods
- Model selection (AIC/BIC)
- Publication-quality visualizations
- Comprehensive test suite"
echo 提交已创建
echo.

echo [6/6] 添加远程仓库并推送...
git remote add origin https://github.com/seezymes/EnzymeKinetics-Skill.git
if errorlevel 1 (
    echo 远程仓库可能已存在，移除后重新添加...
    git remote remove origin
    git remote add origin https://github.com/seezymes/EnzymeKinetics-Skill.git
)

git branch -M main

echo 正在推送到 GitHub...
echo 如果提示输入用户名和密码：
echo - 用户名：seezymes
echo - 密码：您的 GitHub Personal Access Token
echo.
echo ========================================
git push -u origin main
echo.

if errorlevel 1 (
    echo.
    echo ========================================
    echo 推送失败！可能的原因：
    echo 1. 需要创建 GitHub Personal Access Token
    echo 2. 用户名或密码错误
    echo.
    echo 创建 Token 步骤：
    echo 1. 访问：https://github.com/settings/tokens
    echo 2. 点击 "Generate new token (classic)"
    echo 3. 勾选 "repo" 权限
    echo 4. 生成并复制 token
    echo 5. 在提示输入密码时粘贴 token
    echo ========================================
) else (
    echo.
    echo ========================================
    echo 上传成功！
    echo 仓库地址：https://github.com/seezymes/EnzymeKinetics-Skill
    echo ========================================
)

echo.
pause
