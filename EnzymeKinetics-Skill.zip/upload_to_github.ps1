# GitHub 代码上传脚本 (PowerShell 版本)
# 用途：将 EnzymeKinetics-Skill 代码上传到 GitHub

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "EnzymeKinetics-Skill 代码上传工具" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 切换到项目目录
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptPath

# 检查 Git 安装
Write-Host "[1/6] 检查 Git 安装..." -ForegroundColor Yellow
try {
    $gitVersion = git --version 2>&1
    Write-Host "Git 已安装: $gitVersion" -ForegroundColor Green
} catch {
    Write-Host "错误：未检测到 Git！请先安装 Git。" -ForegroundColor Red
    Write-Host "访问：https://git-scm.com/download/win" -ForegroundColor Yellow
    Read-Host "按任意键退出"
    exit 1
}
Write-Host ""

# 配置 Git 用户信息
Write-Host "[2/6] 配置 Git 用户信息..." -ForegroundColor Yellow
git config user.name "Qi Gao"
git config user.email "joan.gao@seezymes.com"
Write-Host "用户信息已配置" -ForegroundColor Green
Write-Host ""

# 初始化 Git 仓库
Write-Host "[3/6] 初始化 Git 仓库..." -ForegroundColor Yellow
git init
Write-Host "仓库已初始化" -ForegroundColor Green
Write-Host ""

# 添加所有文件
Write-Host "[4/6] 添加所有文件..." -ForegroundColor Yellow
git add .
Write-Host "文件已添加到暂存区" -ForegroundColor Green
Write-Host ""

# 创建初始提交
Write-Host "[5/6] 创建初始提交..." -ForegroundColor Yellow
$commitMessage = @"
Initial commit: EnzymeKinetics-Skill v2.0.0

Features:
- Weighted nonlinear regression
- Bootstrap confidence intervals with BCa correction
- Outlier detection (residuals, Cook's distance, robust Z-score)
- Multiple linear transformation methods
- Model selection (AIC/BIC)
- Publication-quality visualizations
- Comprehensive test suite
"@
git commit -m $commitMessage
Write-Host "提交已创建" -ForegroundColor Green
Write-Host ""

# 添加远程仓库并推送
Write-Host "[6/6] 添加远程仓库并推送..." -ForegroundColor Yellow
$remoteUrl = "https://github.com/seezymes/EnzymeKinetics-Skill.git"

try {
    git remote add origin $remoteUrl
} catch {
    Write-Host "远程仓库可能已存在，移除后重新添加..." -ForegroundColor Yellow
    git remote remove origin
    git remote add origin $remoteUrl
}

git branch -M main

Write-Host "正在推送到 GitHub..." -ForegroundColor Cyan
Write-Host "如果提示输入用户名和密码：" -ForegroundColor Yellow
Write-Host "- 用户名：seezymes" -ForegroundColor White
Write-Host "- 密码：您的 GitHub Personal Access Token" -ForegroundColor White
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan

try {
    git push -u origin main
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "上传成功！" -ForegroundColor Green
    Write-Host "仓库地址：https://github.com/seezymes/EnzymeKinetics-Skill" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
} catch {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host "推送失败！可能的原因：" -ForegroundColor Red
    Write-Host "1. 需要创建 GitHub Personal Access Token" -ForegroundColor Yellow
    Write-Host "2. 用户名或密码错误" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "创建 Token 步骤：" -ForegroundColor Yellow
    Write-Host "1. 访问：https://github.com/settings/tokens" -ForegroundColor White
    Write-Host "2. 点击 'Generate new token (classic)'" -ForegroundColor White
    Write-Host "3. 勾选 'repo' 权限" -ForegroundColor White
    Write-Host "4. 生成并复制 token" -ForegroundColor White
    Write-Host "5. 在提示输入密码时粘贴 token" -ForegroundColor White
    Write-Host "========================================" -ForegroundColor Red
}

Write-Host ""
Read-Host "按任意键退出"
