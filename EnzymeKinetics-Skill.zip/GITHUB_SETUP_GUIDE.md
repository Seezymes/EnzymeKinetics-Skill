# GitHub 仓库创建和代码上传指南

## 📋 准备工作清单

在开始之前，请确保您已完成以下准备工作：

### ✅ 1. 安装 Git（如果尚未安装）

**Windows:**
1. 访问：https://git-scm.com/download/win
2. 下载并安装 Git for Windows
3. 安装时保持默认设置
4. 安装完成后，打开 PowerShell 或 Command Prompt，验证安装：
   ```bash
   git --version
   ```
   如果看到版本号（如 `git version 2.x.x`），说明安装成功。

**macOS:**
```bash
# 如果您已安装 Homebrew
brew install git

# 或者通过 Xcode 命令行工具安装
xcode-select --install
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install git
```

### ✅ 2. 配置 Git 用户信息

安装 Git 后，配置您的用户信息（仅需一次）：

```bash
git config --global user.name "Qi Gao"
git config --global user.email "joan.gao@seezymes.com"
```

验证配置：
```bash
git config --list
```

---

## 🚀 第一步：在 GitHub 上创建仓库

### 操作步骤：

1. **访问 GitHub 创建页面**
   - 打开浏览器，访问：https://github.com/new

2. **填写仓库信息**
   ```
   Repository name: EnzymeKinetics-Skill
   Description: An Intelligent Tool for Automated Enzyme Kinetic Parameter Analysis
   Visibility: Public (公开)
   ✅ Add a README file: 不要勾选
   ✅ Add .gitignore: 不要勾选
   ✅ Choose a license: 不要勾选
   ```

3. **创建仓库**
   - 点击绿色按钮 "Create repository"

4. **记录仓库地址**
   创建成功后，您会看到：
   ```
   https://github.com/seezymes/EnzymeKinetics-Skill.git
   ```
   （请记下这个地址）

---

## 📦 第二步：上传本地代码到 GitHub

### 方法一：使用命令行（推荐）

1. **打开终端/命令提示符**
   - Windows: PowerShell 或 Command Prompt
   - macOS: Terminal
   - Linux: Terminal

2. **导航到项目目录**
   ```bash
   cd D:\WorkBuddyWorkspace\EnzymeKinetics-Skill
   ```

3. **初始化 Git 仓库**
   ```bash
   git init
   ```

4. **添加所有文件到暂存区**
   ```bash
   git add .
   ```

5. **创建初始提交**
   ```bash
   git commit -m "Initial commit: EnzymeKinetics-Skill v2.0.0"
   ```

6. **添加远程仓库**
   ```bash
   git remote add origin https://github.com/seezymes/EnzymeKinetics-Skill.git
   ```

7. **推送到 GitHub**
   ```bash
   git branch -M main
   git push -u origin main
   ```

   如果提示输入用户名和密码：
   - **用户名**: `seezymes`
   - **密码**: 您的 GitHub Personal Access Token（需要先创建，见下方）

### 方法二：使用 GitHub Desktop（图形界面）

如果您更喜欢图形界面操作：

1. **下载 GitHub Desktop**
   - 访问：https://desktop.github.com/
   - 下载并安装 GitHub Desktop

2. **登录您的 GitHub 账号**
   - 打开 GitHub Desktop
   - 登录您的账号（seezymes）

3. **添加本地仓库**
   - File → Add Local Repository...
   - 选择 `D:\WorkBuddyWorkspace\EnzymeKinetics-Skill`

4. **发布到 GitHub**
   - 点击 "Publish repository"
   - 填写仓库名称：`EnzymeKinetics-Skill`
   - 选择 "Public"
   - 点击 "Publish repository"

---

## 🔑 第三步：创建 GitHub Personal Access Token（如果使用方法一）

如果使用命令行推送时需要密码，GitHub 不再支持密码登录，需要创建 Personal Access Token：

1. **访问 Token 设置页面**
   - 访问：https://github.com/settings/tokens
   - 点击 "Generate new token" → "Generate new token (classic)"

2. **配置 Token**
   - **Note**: EnzymeKinetics-Skill Upload
   - **Expiration**: 选择 "No expiration" 或设置一个合理的过期时间
   - **Select scopes**: 勾选以下选项：
     - ✅ repo (完全控制仓库)
     - ✅ workflow (如果需要 GitHub Actions)

3. **生成并保存 Token**
   - 点击 "Generate token"
   - **重要**：立即复制并保存 token（只显示一次！）
   - 在 Git 推送时，用此 token 替代密码

4. **使用 Token 推送**
   ```bash
   git push -u origin main
   # 提示输入用户名: seezymes
   # 提示输入密码: <粘贴您的 token>
   ```

---

## ✨ 第四步：启用 GitHub Pages（用于文档展示）

上传代码后，您可以启用 GitHub Pages 来展示项目文档：

1. **访问仓库设置**
   - 访问：https://github.com/seezymes/EnzymeKinetics-Skill/settings/pages

2. **配置 GitHub Pages**
   - **Source**: Deploy from a branch
   - **Branch**: main
   - **Folder**: / (root) 或 /docs
   - 点击 "Save"

3. **等待部署**
   - 等待几分钟，GitHub 会自动构建和部署
   - 您的网站地址：https://seezymes.github.io/EnzymeKinetics-Skill/

---

## 📊 第五步：验证上传成功

上传完成后，访问以下链接验证：

1. **主仓库页面**
   - https://github.com/seezymes/EnzymeKinetics-Skill

2. **检查文件列表**
   - 应该看到所有文件：README.md, LICENSE, setup.py 等

3. **查看 README**
   - 确认 README.md 正确显示

4. **测试克隆**
   ```bash
   git clone https://github.com/seezymes/EnzymeKinetics-Skill.git
   ```

---

## 🔧 常见问题解决

### Q1: 提示 "fatal: not a git repository"
**解决**：确保您在正确的目录中：
```bash
cd D:\WorkBuddyWorkspace\EnzymeKinetics-Skill
git init
```

### Q2: 提示 "Authentication failed"
**解决**：创建并使用 GitHub Personal Access Token（见第三步）

### Q3: 提示 "remote origin already exists"
**解决**：移除旧的远程仓库地址：
```bash
git remote remove origin
git remote add origin https://github.com/seezymes/EnzymeKinetics-Skill.git
```

### Q4: 推送时出现 SSL 错误
**解决**：禁用 SSL 验证（临时解决方案）：
```bash
git config --global http.sslVerify false
```
或者使用 SSH 替代 HTTPS。

---

## 📝 下一步建议

上传成功后，建议您：

1. **更新论文中的仓库链接**
   - 将 `https://github.com/username/EnzymeKinetics-Skill`
   - 改为 `https://github.com/seezymes/EnzymeKinetics-Skill`

2. **添加更多示例代码**
   - 在 `examples/` 文件夹中添加更多使用示例

3. **完善文档**
   - 在 `docs/` 文件夹中添加详细的使用文档

4. **创建发布版本**
   - 在 GitHub 上创建 Release 标签（如 v2.0.0）
   - 上传论文的 PDF 版本

5. **添加 CI/CD**
   - 配置 GitHub Actions 自动运行测试

---

## 💡 需要帮助？

如果遇到问题，可以：

1. 查看 GitHub 官方文档：https://docs.github.com/
2. 提交 Issue 到本仓库（如果已创建）
3. 联系作者：joan.gao@seezymes.com

---

**祝您操作顺利！🎉**
